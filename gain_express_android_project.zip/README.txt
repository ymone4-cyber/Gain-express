# Gain Express — projet installable Android

Cette version est une PWA (application web installable) hors ligne, pour une simulation éducative de sensibilisation au phishing.

## Tester
1. Déployer le contenu de ce dossier sur un hébergement HTTPS (par exemple GitHub Pages).
2. Ouvrir l'adresse publiée sur Android avec Chrome.
3. Utiliser le menu Chrome puis « Installer l'application » ou « Ajouter à l'écran d'accueil ».

## Préparer une publication Google Play
1. Vérifier que l'application explique clairement qu'il s'agit d'une simulation éducative.
2. Publier le site en HTTPS et tester sur plusieurs téléphones.
3. Ouvrir https://www.pwabuilder.com/ et saisir l'URL publique de l'application.
4. Suivre les instructions PWABuilder pour générer un paquet Android (AAB) et le signer.
5. Créer un compte développeur Google Play Console, compléter les informations de l'application, la politique de confidentialité et les tests requis, puis envoyer l'AAB en examen.

Important : ce dossier n'est pas encore un APK/AAB signé et l'application n'est pas publiée sur Play Store. Google doit examiner et approuver l'application. Les règles et exigences Play Console peuvent évoluer. Ne collectez pas de vrais numéros, mots de passe, PIN ou codes SMS.
